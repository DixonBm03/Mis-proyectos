
package Persistencia;

import Logica.Controlador;
import Vista.VentanaPrincipal;

/**
 *
 * @author busto
 */
public class Modelo extends Controlador {

    public Modelo(VentanaPrincipal vp, Modelo model) {
        super(vp, model);
    }

   
}
    
