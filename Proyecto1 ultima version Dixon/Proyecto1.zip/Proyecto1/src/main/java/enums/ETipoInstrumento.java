
package enums;


public enum ETipoInstrumento {
    Termometro,
    Barometro,
    Cronometro;
}
