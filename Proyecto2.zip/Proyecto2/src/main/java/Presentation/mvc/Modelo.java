/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentation.mvc;

import Presentation.datacontract.Calibraciones;
import Presentation.datacontract.Instrumento;
import Presentation.datacontract.TipoInstrumento;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author busto
 */
public class Modelo {
    private LinkedList<TipoInstrumento> tipoInstrumentos = new LinkedList<>();
    private LinkedList<Instrumento> instrumentos = new LinkedList<>();
    private List<Calibraciones> listaCalibraciones = new ArrayList<>();
    private  Map<String,String> TipoIns = new HashMap<>();
    private  Map<String,String[]> medicion = new HashMap<>();
    private int numeroCalibraciones = 0;
    private int numInsCalibraion=1;
    private int numMedida=0;
    public Modelo() {
    }
    public void eliminarTipoInstrumentoPorCodigo(String codigo) {
        // Itera sobre la lista TipoInstrumento
        for (TipoInstrumento tipoInstrumento : tipoInstrumentos) {
            // Comprueba si el código coincide
            if (tipoInstrumento.getCodigo().equals(codigo)) {
                // Elimina el TipoInstrumento de la lista
                tipoInstrumentos.remove(tipoInstrumento);
                return; // Termina el método después de eliminar el TipoInstrumento
            }
        }
        // Si llegamos aquí, significa que no se encontró ningún TipoInstrumento con el código especificado
        System.out.println("No se encontró ningún TipoInstrumento con el código especificado.");
    }
    public void eliminarTipoInsMapKeyAll() {
        TipoIns.clear();
    }
    public void generar1() throws DocumentException{
        try {
            FileOutputStream archivo = new FileOutputStream("TiposInstrumentos.pdf");
            com.itextpdf.text.Document doc= new com.itextpdf.text.Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();
            Paragraph parrafo = new Paragraph("Tipos de Instrumentos");
            parrafo.setAlignment(1);
            doc.add(parrafo);
            for(int i = 0; i < tipoInstrumentos.size(); i++){
                doc.add(new Paragraph("Codigo: " + tipoInstrumentos.get(i).getCodigo()));
                doc.add(new Paragraph("Nombre: " + tipoInstrumentos.get(i).getNombre()));
                doc.add(new Paragraph("Unidad: " + tipoInstrumentos.get(i).getUnidad()));
                doc.add(new Paragraph("\n\n"));
            }
            doc.close();
            File path = new File("TiposInstrumentos.pdf");
            Desktop.getDesktop().open(path);
        } catch (IOException ex) {
           
        }
    }
    public void eliminarInstrumentoPorSerie(String serie) {
        Iterator<Instrumento> iter = instrumentos.iterator();
        while (iter.hasNext()) {
            Instrumento instrumento = iter.next();
            if (instrumento.getSerie().equals(serie)) {
                iter.remove(); // Elimina el instrumento de la lista
            }
        }
    }
}
