/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Presentation.mvc;


import Presentation.datacontract.Calibraciones;
import Presentation.datacontract.Instrumento;
import Presentation.datacontract.TipoInstrumento;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author busto
 */
public class Controlador implements ActionListener{
    private Vista view;
    private Modelo mod;
    LinkedList<TipoInstrumento> TiposInstrumento =new LinkedList<>();
    LinkedList<Instrumento> instrumento =new LinkedList<>();
    LinkedList<Calibraciones> calibracion =new LinkedList<>();
    private DefaultTableModel modeloTipo;
    DefaultTableModel modeloInstrumento;
    DefaultTableModel modeloCalibracion;
    DefaultTableModel modeloMedidas;
    private TableRowSorter trsfiltro;
    private LinkedList<Instrumento> instrumentos = new LinkedList<>();
    public Controlador(Vista view, Modelo mod) {
        this.view = view;
        this.mod = mod;
        // Crea el modelo de datos para el JTable
        modeloTipo = new DefaultTableModel();
        modeloTipo.addColumn("Código");
        modeloTipo.addColumn("Nombre");
        modeloTipo.addColumn("Unidad de Medida");
        view.getJtableTipo().setModel(modeloTipo);
        
        //crea la tabla instrumento 
        modeloInstrumento=new DefaultTableModel();
        modeloInstrumento.addColumn("Serie");
        modeloInstrumento.addColumn("Descripcion");
        modeloInstrumento.addColumn("Minimo");
        modeloInstrumento.addColumn("Maximo");
        modeloInstrumento.addColumn("Tolerancia");
        view.getJtableInstrumento().setModel(modeloInstrumento);
        //se levanta la vista aplicando MVC
        view.setVisible(true);
        view.setLocationRelativeTo(null);
        this.view.getJbtnGuardar().addActionListener(this);
        this.view.getJbtnGuarIns().addActionListener(this);
        this.view.getJbtnGuarCal().addActionListener(this);
        this.view.getJbtnGuarMed().addActionListener(this);
        this.view.getJbtnLimpiar().addActionListener(this);
        this.view.getJbtnLimpIns().addActionListener(this);
        this.view.getJbtnLimpCal().addActionListener(this);
        this.view.getJbtnLimpMed().addActionListener(this);
        this.view.getJbtnBorrar().addActionListener(this);
        this.view.getJbtnBorrIns().addActionListener(this);
        this.view.getJbtnBorrCal().addActionListener(this);
        this.view.getJbtnBorrMed().addActionListener(this);
        this.view.getJbtnBuscar().addActionListener(this);
        this.view.getJbtnBusIns().addActionListener(this);
        this.view.getJbtnBusCal().addActionListener(this);
        this.view.getJbtnReporte().addActionListener(this);
        this.view.getJbtnRepIns().addActionListener(this);
        this.view.getJbtnRepoCal().addActionListener(this);
        view.getJbtnBorrar().setEnabled(false);
        view.getJbtnBorrIns().setEnabled(false);
        view.getJbtnBorrCal().setEnabled(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource().equals(view.getJbtnGuardar())) {
            guardarTipo();
        }
        else if (e.getSource().equals(view.getJbtnLimpiar())) {
            limpiarTipo();
            view.getJbtnBorrar().setEnabled(false);
            view.txtCode().setEnabled(true);
            //jTabbedPane1.setEnabledAt(1, false);
            //view.getjTabbedPane1().setEnabledAt(2, false);
        }
        else if (e.getSource().equals(view.getJbtnBorrar())) {
            borrarTipo();
        }
        else if (e.getSource().equals(view.getJbtnBuscar())) {
            escogerTipoInstrumentoBusqueda();
            
        }
        else if (e.getSource().equals(view.getJbtnReporte())) {
            try {
                generarPDFDesdeJTable(view.getJtableTipo());
                //mod.generar1();
            } catch (DocumentException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource().equals(view.getJbtnGuarIns())) {
            guardarInstrumento();
        }
        else if (e.getSource().equals(view.getJbtnLimpIns())) {
           limpiarInstrumento();
        }
        else if (e.getSource().equals(view.getJbtnBorrIns())) {
            borrarInstrumento();
        }
        else if (e.getSource().equals(view.getJbtnBusIns())) {
             buscarInstrumento();
        }
        else if (e.getSource().equals(view.getJbtnRepIns())) {
            try {
                generarPDFInstrumento(view.getJtableInstrumento());
            } catch (DocumentException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if (e.getSource().equals(e)) {
          
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
        else if (e.getSource().equals(e)) {
            
        }
                
    }
    public Vista getView() {
        return view;
    }

    public void setView(Vista view) {
        this.view = view;
    }

    public Modelo getMod() {
        return mod;
    }

    public void setMod(Modelo mod) {
        this.mod = mod;
    }
    
    public void guardarTipo(){
        boolean entra=true;
        view.getJbtnBorrar().setEnabled(true);
        if(view.getJtxtCodigo().isEmpty()||view.getJtxtNombre().isEmpty()||view.getJtxtUnidad().isEmpty()){
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            entra=false;
        }
        if(entra==true){
            if(view.txtCode().isEnabled()){
            //if (controlador.VerificaCodigoTipo()) {
            //mostrarError("el codigo ya existe.");
        
            //}else{
            cargarTableTipo();
            limpiarTipo();
            //}
            }else{
                cargarTableTipo();
                ActualizarDatoTipoI();
            }
        }
    }
     public void cargarTableTipo(){
        String[] Datos = new String[3];
        Datos[0] = view.getJtxtCodigo();
        Datos[1] = view.getJtxtNombre();
        Datos[2] = view.getJtxtUnidad();
        cargarTableTipos(Datos);
    }
    public void cargarTableTipos(String[] Datos){
        modeloTipo.addRow(Datos);   
    }

    public void ActualizarDatoTipoI() {
        String nombre = view.getJtxtNombre();
        String unidad = view.getJtxtUnidad();
        String codigo = buscarYObtenerValor(nombre);
        int filaExistente = -1;

        // Verificar si el dato ya existe en la tabla
        for (int i = 0; i < view.getJtableTipo().getRowCount(); i++) {
            String codN = view.getJtableTipo().getValueAt(i, 0).toString();
            String nomN = view.getJtableTipo().getValueAt(i, 1).toString();
            String uniN = view.getJtableTipo().getValueAt(i, 2).toString();

            if (codN.equals(codigo)) {
                filaExistente = i;

                if (nomN.equals(nombre)) {
                    filaExistente = i;

                    if (uniN.equals(unidad)) {
                        filaExistente = i;
                        break;
                    }
                }

                // Si el dato existe, elimínalo
                if (filaExistente != -1) {
                  borrarFilaExisteTipo(filaExistente);
                  mod.eliminarTipoInstrumentoPorCodigo(codigo);
                  mod.eliminarTipoInsMapKeyAll();
                  //modelo.eliminarTipoInsMapKey(nombre);
                  //modelo.eliminarTipoInsMapKeyAll();
                  //vista.getJcboTipo().removeAllItems();
                  JOptionPane.showConfirmDialog(null, "TipoIntrumento("+codigo+") actualizado");
                }

            }

        }
    }
    public void borrarFilaExisteTipo(int pos){
        modeloTipo.removeRow(pos);
    }
    
    public String buscarYObtenerValor(String nombre) {
        DefaultTableModel model = (DefaultTableModel) view.getJtableTipo().getModel();

        // Iterar a través de las filas del jTable
        for (int i = 0; i < model.getRowCount(); i++) {
        // Obtener el valor en la columna 1 (segunda columna)
            String valorColumna1 = model.getValueAt(i, 1).toString();

            // Comparar con el nombre proporcionado
            if (valorColumna1.equals(nombre)) {
            // Si se encuentra el nombre, retornar el contenido de la columna 0 (primera columna)
                return model.getValueAt(i, 0).toString();
            }
        }

        // Si no se encuentra el nombre, puedes retornar un valor por defecto o lanzar una excepción, según tus necesidades
        return "No encontrado"; // O cualquier otro valor por defecto
    }
    public void limpiarTipo(){
        view.txtCode().setText("");
        view.txtNombre().setText("");
        view.txtUnidad().setText("");
        view.txtNomBusqueda().setText("");
        view.getJbtnBorrar().setEnabled(false);
        view.txtCode().setEnabled(true);
        view.getJtableTipo().clearSelection();
        trsfiltro=new TableRowSorter(view.getJtableTipo().getModel());
        view.getJtableTipo().setRowSorter(trsfiltro);
    }
    public void borrarTipo(){
        int filaSeleccionada = view.getJtableTipo().getSelectedRow();
        if (filaSeleccionada >= 0) {
           modeloTipo.removeRow(filaSeleccionada);
           JOptionPane.showMessageDialog(null, "Se ha eliminado con exito!!!.");
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un Tipo de Instrumento para borrar.");
        }
        limpiarTipo();
    }
    public void escogerTipoInstrumentoBusqueda(){
        String buscaN = view.getJtxtNomBusqueda();
        String buscarC =view.getJtxtCodBusqueda();
        if(buscarC.isEmpty()){
             // Crear un TableRowSorter para filtrar las filas de la tabla
            TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(view.getTablaTipoModel());
            view.getJtableTipo().setRowSorter(sorter);
            // Crear un filtro para mostrar solo las filas que contienen el dato buscado en la columna "Codigo"
           RowFilter<DefaultTableModel, Object> filter = RowFilter.regexFilter(buscaN, 1);
            sorter.setRowFilter(filter);
        }else{
            // Crear un TableRowSorter para filtrar las filas de la tabla
            TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(view.getTablaTipoModel());
            view.getJtableTipo().setRowSorter(sorter);
            // Crear un filtro para mostrar solo las filas que contienen el dato buscado en la columna "Codigo"
            RowFilter<DefaultTableModel, Object> filter = RowFilter.regexFilter(buscarC, 0);
            sorter.setRowFilter(filter);
        }
    }
    public void generarPDFDesdeJTable(JTable jTableTipo) throws DocumentException {
         try {
            FileOutputStream archivo = new FileOutputStream("TiposInstrumentos.pdf");
            com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();
            Paragraph parrafo = new Paragraph("Tipos de Instrumentos");

            parrafo.setAlignment(1);
            doc.add(parrafo);

            DefaultTableModel model = (DefaultTableModel) jTableTipo.getModel();

            for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                     String columnName = jTableTipo.getColumnName(col);
                    String cellValue = model.getValueAt(row, col).toString();
                    doc.add(new Paragraph(columnName + ": " + cellValue));
                }
                doc.add(new Paragraph("\n"));
            }

            doc.close();
            File path = new File("TiposInstrumentos.pdf");
            Desktop.getDesktop().open(path);
            } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    //INSTRUMENTO
    public void guardarInstrumento(){
        boolean entra = true;
        if (view.getJtxtSerie().isEmpty() || view.getJtxtDescripcion().isEmpty() || view.getJtxtMinimo().isEmpty() || view.getJtxtMaximo().isEmpty() || view.getJtxtTolerancia().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            entra = false;
        } else {
        // Validar que "minimo" y "maximo" sean números
            try {
                double minimo = Double.parseDouble(view.getJtxtMinimo());
                double maximo = Double.parseDouble(view.getJtxtMaximo());

                if (minimo > maximo) {
                    JOptionPane.showMessageDialog(null, "El valor mínimo no puede ser mayor que el valor máximo.");
                    entra = false;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Los campos 'minimo' y 'maximo' deben contener números válidos.");
                entra = false;
            }
        }
        if (entra) {
        // Validar si la serie ya existe antes de continuar
            if (view.txtserie().isEnabled()) {
                //if (controlador.VerificaSerie()) {
                    //mostrarError("El código ya existe.");
                    //return; // Salir del método si la serie ya existe
                //}else{
                    cargarTableInstrumento(); 
                //}
            }else {
                cargarTableInstrumento();
                ActualizarInstrumento();
            }
            limpiarInstrumento();
            view.getJbtnBorrIns().setEnabled(true);
        }     
    }        

    public void cargarTableInstrumento(){
        String []Dato=new String[5];
        Dato[0]=view.getJtxtSerie();
        Dato[1]=view.getJtxtDescripcion();
        Dato[2]=view.getJtxtMinimo();
        Dato[3]=view.getJtxtMaximo();
        Dato[4]=view.getJtxtTolerancia();
        cargarTableInstrumento(Dato);
    }
    public  void cargarTableInstrumento( String []Dato){
        if(Dato!=null){
            modeloInstrumento.addRow(Dato);
        }
    }

    private void ActualizarInstrumento() {
    String nom=obtenerValorSeleccionado();
    String codigo=buscarYObtenerValor(nom);
      
    String serie = view.getJtxtSerie();
    String descripcion = view.getJtxtDescripcion();
    String minimo = view.getJtxtMinimo();
    String maximo = view.getJtxtMaximo();
    String tolerancia = view.getJtxtTolerancia();

    int filaExistente = -1;
    // Verificar si el dato ya existe en la tabla
    for (int i = 0; i < getTablaInstrumentoModel().getRowCount(); i++) {
            
        String serieN = getTablaInstrumentoModel().getValueAt(i, 0).toString();
        String desN = getTablaInstrumentoModel().getValueAt(i, 1).toString();
        String minN = getTablaInstrumentoModel().getValueAt(i, 2).toString();
        String maxN = getTablaInstrumentoModel().getValueAt(i, 3).toString();
        String tolN = getTablaInstrumentoModel().getValueAt(i, 4).toString();
    
        if (serieN.equals(serie)) {
            filaExistente = i;

            if (desN.equals(descripcion)) {
                filaExistente = i;
                if (minN.equals(minimo)) {
                    filaExistente = i;
                    if (maxN.equals(maximo)) {
                        filaExistente = i;

                        if (tolN.equals(tolerancia)) {
                            filaExistente = i;
                            break;
                        }
                    }
                }
            }

                // Si el dato existe, elimínalo
                if (filaExistente != -1) {  
                    borrarFilaExisteInstrumento( filaExistente);
                    mod.eliminarInstrumentoPorSerie(serie);
                    //cargarInstrumentosPorCodigo(codigo,vista.getTablaInstrumento());
                    limpiarInstrumento();
                    JOptionPane.showMessageDialog(null, "Intrumento (" +serie+ ") actualizado");
                        
                }

            }

        }
    }

    public String obtenerValorSeleccionado() {
        Object selectedItem = view.getJcmbTipo().getSelectedItem();
        if (selectedItem != null) {
            return selectedItem.toString();
        } else {
            return null; // O podrías retornar una cadena vacía ("") en lugar de null si prefieres.
        }
    }
    public DefaultTableModel getTablaInstrumentoModel() {
        return (DefaultTableModel) view.getJtableInstrumento().getModel();
    }

    private void borrarFilaExisteInstrumento(int pos) {
        if (pos>=0) {
            modeloInstrumento.removeRow(pos);
        }
        else{
            JOptionPane.showMessageDialog(null, "Tabla vacia o seleccione un Instrumento");
        }
    }

    private void limpiarInstrumento() {
        view.txtserie().setText("");
        view.txtDescripcion().setText("");
        view.txtMinimo().setText("");
        view.txtMaximo().setText("");
        view.txtTolerancia().setText("");
        view.getJbtnBorrIns().setEnabled(false);
        view.txtserie().setEnabled(true);
        view.getJtableInstrumento().clearSelection();
    
        //controlador.cargarInstrumentosPorCodigo(getCodigoTipo(),getTablaInstrumento());
        //getJTabbedPane1().setEnabledAt(2, false);
        trsfiltro=new TableRowSorter( view.getJtableInstrumento().getModel());
        view.getJtableInstrumento().setRowSorter(trsfiltro);
    }
    
    public void MuestraCalibraciones() {
     String nom=obtenerValorSeleccionado();
       String codigoTipo=buscarYObtenerValor(nom);
  
        String serieInstrumento= view.getJtxtSerie();
 
        //cargarCalibracionesDesdeXML(codigoTipo,  serieInstrumento,vista.getTablaCalibra());
    }
    private void borrarInstrumento(){
        int filaSeleccionada = view.getJtableInstrumento().getSelectedRow();
        if (filaSeleccionada >= 0) {
           modeloInstrumento.removeRow(filaSeleccionada);
           JOptionPane.showMessageDialog(null, "Se ha eliminado con exito!!!.");
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un Tipo de Instrumento para borrar.");
        }
        limpiarTipo();
    }
    private void buscarInstrumento(){
        String buscaDesc = view.getJtxtBuscarDescri();
        String buscarSerie = view.getJtxtSerieBusqueda();
        if(buscarSerie.isEmpty()){
            // Crear un TableRowSorter para filtrar las filas de la tabla
            TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(view.getTablaInstrumentoModel());
            view.getJtableInstrumento().setRowSorter(sorter);
            // Crear un filtro para mostrar solo las filas que contienen el dato buscado en la columna "Codigo"
            RowFilter<DefaultTableModel, Object> filter = RowFilter.regexFilter(buscaDesc, 1);
            sorter.setRowFilter(filter);
        }else{
            //
            // Crear un TableRowSorter para filtrar las filas de la tabla
            TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(view.getTablaInstrumentoModel());
             view.getJtableInstrumento().setRowSorter(sorter);
            // Crear un filtro para mostrar solo las filas que contienen el dato buscado en la columna "Codigo"
            RowFilter<DefaultTableModel, Object> filter = RowFilter.regexFilter(buscarSerie, 0);
            sorter.setRowFilter(filter);
        }
    }
    public void generarPDFInstrumento(JTable jTableTipo) throws DocumentException {
         try {
            FileOutputStream archivo = new FileOutputStream("Instrumentos.pdf");
            com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
            PdfWriter.getInstance(doc, archivo);
            doc.open();
            Paragraph parrafo = new Paragraph("Instrumentos");

            parrafo.setAlignment(1);
            doc.add(parrafo);

            DefaultTableModel model = (DefaultTableModel) jTableTipo.getModel();

            for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                     String columnName = jTableTipo.getColumnName(col);
                    String cellValue = model.getValueAt(row, col).toString();
                    doc.add(new Paragraph(columnName + ": " + cellValue));
                }
                doc.add(new Paragraph("\n"));
            }

            doc.close();
            File path = new File("Instrumentos.pdf");
            Desktop.getDesktop().open(path);
            } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
