/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto2;

import Presentation.mvc.Controlador;
import Presentation.mvc.Modelo;
import Presentation.mvc.Vista;

/**
 *
 * @author busto
 */
public class Proyecto2 {

    public static void main(String[] args) {
        Vista v=new Vista();
        Modelo m=new Modelo();
        Controlador control=new Controlador(v,m);
    }
}
