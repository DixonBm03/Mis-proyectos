/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.datacontract;

/**
 *
 * @author busto
 */
public class UnidadMedida {
    private int ID;
    private String Nombre;
    private String Sigla;
    public UnidadMedida(){
        
    }
    public UnidadMedida(String Nombre, String Sigla) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Sigla = Sigla;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getSigla() {
        return Sigla;
    }

    public void setSigla(String Sigla) {
        this.Sigla = Sigla;
    }
    
}
