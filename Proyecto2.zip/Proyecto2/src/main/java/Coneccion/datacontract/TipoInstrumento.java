/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.datacontract;

/**
 *
 * @author busto
 */
public class TipoInstrumento {
   private String nombre;
   private String codigo;
   private UnidadMedida unidad;
   public TipoInstrumento(){
       
   }
    public TipoInstrumento(String nombre, String codigo, UnidadMedida unidad) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.unidad = unidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public UnidadMedida getUnidad() {
        return unidad;
    }

    public void setUnidad(UnidadMedida unidad) {
        this.unidad = unidad;
    }
}
