/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.datacontract;

/**
 *
 * @author busto
 */
public class Mediciones {
    private int IDMedicion;
    private int IDCalibracion;
    private int IDMedidaCalibracion;
    private int referencia;
    private String lectura;
    private Calibraciones cal;
    private Instrumento ins;
    private String medicioncol;
    private int maximo;
    private int IDCalibracionInstrumento;
    private int IDInstrumento;
    public Mediciones(){
        
    }
    public Mediciones(int IDMedicion, int IDCalibracion, int IDMedidaCalibracion, int referencia, String lectura, String medicioncol) {
    this.IDMedicion = IDMedicion;
    this.IDCalibracion = IDCalibracion;
    this.IDMedidaCalibracion = IDMedidaCalibracion;
    this.referencia = referencia;
    this.lectura = lectura;
    this.medicioncol=medicioncol;
    }

    public String getMedicioncol() {
        return medicioncol;
    }
    
    public int getIDInstrumento() {
        return IDInstrumento;
    }
    
    public int getIDCalibracionInstrumento() {
        return IDCalibracionInstrumento;
    }
    
    public Instrumento getIns() {
        return ins;
    }
    
    public Calibraciones getCal() {
        return cal;
    }
    
    public int getIDMedicion() {
        return IDMedicion;
    }

    public void setIDMedicion(int IDMedicion) {
        this.IDMedicion = IDMedicion;
    }

    public int getIDCalibracion() {
        return IDCalibracion;
    }

    public void setIDCalibracion(int IDCalibracion) {
        this.IDCalibracion = IDCalibracion;
    }

    public int getIDMedidaCalibracion() {
        return IDMedidaCalibracion;
    }

    public void setIDMedidaCalibracion(int IDMedidaCalibracion) {
        this.IDMedidaCalibracion = IDMedidaCalibracion;
    }
    
    public int getReferencia() {
        return referencia;
    }

    public void setReferencia(int referencia) {
        this.referencia = referencia;
    }

    public String getLectura() {
        return lectura;
    }

    public void setLectura(String lectura) {
        this.lectura = lectura;
    }
}
