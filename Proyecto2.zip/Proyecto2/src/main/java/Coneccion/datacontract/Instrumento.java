/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.datacontract;

/**
 *
 * @author busto
 */
public class Instrumento {
    private long serie;
    private String descripcion;
    private int minimo;
    private int maximo;
    private int tolerancia;
    private String CodigoTipoInstrumento;
    public Instrumento(){
        
    }
    public Instrumento(long serie, String descripcion, int minimo, int maximo, int tolerancia, String CodigoTipoInstrumento) {
        this.serie = serie;
        this.descripcion = descripcion;
        this.minimo = minimo;
        this.maximo = maximo;
        this.tolerancia = tolerancia;
        this.CodigoTipoInstrumento=CodigoTipoInstrumento;
    }

    public long getSerie() {
        return serie;
    }

    public String getCodigoTipoInstrumento() {
        return CodigoTipoInstrumento;
    }

    public void setCodigoTipoInstrumento(String CodigoTipoInstrumento) {
        this.CodigoTipoInstrumento = CodigoTipoInstrumento;
    }
    
    public void setSerie(long serie) {
        this.serie = serie;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getMinimo() {
        return minimo;
    }

    public void setMinimo(int minimo) {
        this.minimo = minimo;
    }

    public int getMaximo() {
        return maximo;
    }

    public void setMaximo(int maximo) {
        this.maximo = maximo;
    }

    public int getTolerancia() {
        return tolerancia;
    }

    public void setTolerancia(int tolerancia) {
        this.tolerancia = tolerancia;
    }
    
}
