/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.datacontract;

/**
 *
 * @author busto
 */
public class Calibraciones {
    private int IDInstrumento;
    private int medicion;  //= a IDCalibracionInstrumento
    private java.util.Date FechaCalibracion;

    public Calibraciones(int IDInstrumento, int medicion, java.util.Date FechaCalibracion) {
        this.IDInstrumento = IDInstrumento;
        this.medicion = medicion;
        this.FechaCalibracion = FechaCalibracion;
    }
    
    public int getIDInstrumento() {
        return IDInstrumento;
    }

    public void setIDInstrumento(int IDInstrumento) {
        this.IDInstrumento = IDInstrumento;
    }

    public int getMedicion() {
        return medicion;
    }

    public void setIDCalibracionInstrumento(int medicion) {
        this.medicion=medicion;
    }

    public java.util.Date getFecha() {
        return FechaCalibracion;
    }

    public void setFecha(java.util.Date FechaCalibracion) {
        this.FechaCalibracion = FechaCalibracion;
    }
    
}
