/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion;

import Coneccion.conect.BDconeccion;
import Coneccion.conect.ConsultaCalibraciones;
import Coneccion.conect.ConsultaInstrumento;
import Coneccion.conect.ConsultaMediciones;
import Coneccion.conect.ConsultaTipoInstrumento;
import Coneccion.conect.ConsultaUnidadMedida;
import Coneccion.datacontract.Calibraciones;
import Coneccion.datacontract.Instrumento;
import Coneccion.datacontract.Mediciones;
import Coneccion.datacontract.TipoInstrumento;
import Coneccion.datacontract.UnidadMedida;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author busto
 */
public class PaquetePadre {
    public static void main(String[] args) {
        //INSERTAR UNIDAD DE MEDIDA
        //UnidadMedida unidad=new UnidadMedida("Barometro", "BAR");
        //ConsultaUnidadMedida consulta=new ConsultaUnidadMedida();
        //consulta.insertarUnidadMedida(unidad);
        //TipoInstrumento tipo=new TipoInstrumento("Termo", "TER", unidad);
        //ConsultaTipoInstrumento consultaTipo=new ConsultaTipoInstrumento();
        //consultaTipo.insertarTipoInstrumento(tipo);
        //MODIFICAR UNIDAD DE MEDIDA
        //consulta.modificarUnidadMedida(unidad);
        //BUSCAR UNIDAD DE MEDIDA
        /*String consultarBusqueda = "BAR"; 
        List<UnidadMedida> resultados = consulta.buscarUnidadMedidaPorNombreOSigla(consultarBusqueda);
        if (resultados.isEmpty()) {
        System.out.println("No se encontraron resultados para la consulta: " + consulta);
        } else {
        System.out.println("Se encontraron resultados para la consulta: " + consulta);
        }*/
        //ELIMINAR UNIDAD DE MEDIDA
        //consulta.eliminarUnidadMedidaPorNumeroDeFila(3);
        
        //INSERTAR TIPO INSTRUMENTO
        //TipoInstrumento tipo=new TipoInstrumento("Termometro", "TER", unidad);
        //ConsultaTipoInstrumento consultaTipo=new ConsultaTipoInstrumento();
        //consultaTipo.insertarTipoInstrumento(tipo);
        //MODIFICAR TIPO INSTRUMENTO
        //consultaTipo.modificarTipoInstrumento(tipo);
        //BUSCAR TIPO INSTRUMENTO
        /*String BuscarTipo = "Cronometro";

        // Llama al método para buscar Tipos de Instrumento
        List<TipoInstrumento> resultados = consultaTipo.buscarTipoInstrumentoPorNombreOCodigo(BuscarTipo);

        if (resultados.isEmpty()) {
            System.out.println("No se encontraron resultados para la consulta: " + consulta);
        } else {
            System.out.println("Se encontraron resultados para la consulta: " + consulta);
        }*/
        //ELIMINAR TIPO INSTRUMENTO
       //consultaTipo.eliminarTipoInstrumentoPorNumeroDeFila(3);
       //INSTRUMENTO
       //Instrumento instru=new Instrumento(1784216 , "Termómetro industrial Beck la mejor 2023 ",-20,120,2,"TER");
       //ConsultaInstrumento consultaIns=new ConsultaInstrumento();
       //INSERCION INSTRUMENTO
       //consultaIns.insertarInstrumento(instru);
       //ACTUALIZAR INSTRUMENTO
       //consultaIns.actualizarInstrumento(instru);
       //BUSCAR INSTRUMENTO
        /*Object consulta="Barómetro de mesa Harrison";
        // Ejemplo de búsqueda por Descripción
        boolean encontradoPorDescripcion = consultaIns.buscarInstrumentoPorValor(consulta);

        if (encontradoPorDescripcion) {
            System.out.println("Se encontró un instrumento.");
        } else {
            System.out.println("No se encontró ningún instrumento.");
        }*/
        //ELIMINAR INSTRUMENTO
        //consultaIns.eliminarInstrumentoPorNumeroDeFila(3);
        //Calibracion, 
        //Insertar Calibracion
        /*java.util.Date fechaActual = new java.util.Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String fechaFormateada = sdf.format(fechaActual);
        Calibraciones cali=new Calibraciones(1546715,0,fechaActual);
        ConsultaCalibraciones consultaCal=new ConsultaCalibraciones();*/
        //consultaCal.insertarCalibracion(cali);
        //ACTUALIZAR CALIBRACION
        //consultaCal.actualizarCalibracionInstrumento(cali);
        //Buscar CALIBRACION
        //System.out.println(consultaCal.buscarCalibracionPorIDCalibracionInstrumento(2));
        //ELIMINAR CALIBRACION
        //ConsultaCalibraciones consultaCal=new ConsultaCalibraciones();
        //consultaCal.eliminarCalibracionPorNumeroDeFila(1);
        //MEDICIONES
        //Guardar MEDICION
        /*ConsultaMediciones consultaMed =new ConsultaMediciones();
        // Crear una instancia de Medicion con los datos que deseas insertar
        Mediciones medicion = new Mediciones(1234, 2, 321, 100, "100", "2");
        // Llamar al método para insertar la medición
        consultaMed.insertarMedicion(medicion);*/
        //BORRAR MEDICION
        //ConsultaMediciones consultaMed =new ConsultaMediciones();
        //consultaMed.eliminarMedicionPorNumeroDeFila(1);
    }
    
}
