CREATE DATABASE `silab` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;


CREATE TABLE `unidadmedida` (
  `IDUnidadMedida` int unsigned NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Sigla` varchar(45) NOT NULL,
  PRIMARY KEY (`IDUnidadMedida`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `tipoinstrumento` (
  `CodigoTipoInstrumento` varchar(3) NOT NULL,
  `NombreTipoInstrumento` varchar(45) NOT NULL,
  `IDUnidadMedida` int unsigned NOT NULL,
  PRIMARY KEY (`CodigoTipoInstrumento`),
  KEY `FKIDUnidadMedida_idx` (`IDUnidadMedida`),
  CONSTRAINT `FKIDUnidadMedida` FOREIGN KEY (`IDUnidadMedida`) REFERENCES `unidadmedida` (`IDUnidadMedida`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `instrumento` (
  `IDInstrumento` bigint NOT NULL,
  `CodigoTipoInstrumento` varchar(3) NOT NULL,
  `Description` varchar(45) NOT NULL,
  `minimo` int NOT NULL,
  `maximo` int NOT NULL,
  `tolerancia` int NOT NULL,
  PRIMARY KEY (`IDInstrumento`),
  KEY `FKCodigoTipoInstrumento_idx` (`CodigoTipoInstrumento`),
  CONSTRAINT `FKCodigoTipoInstrumento` FOREIGN KEY (`CodigoTipoInstrumento`) REFERENCES `tipoinstrumento` (`CodigoTipoInstrumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `calibracion` (
  `IDCalibracion` int unsigned NOT NULL AUTO_INCREMENT,
  `IDInstrumento` bigint NOT NULL,
  `IDCalibracionInstrumento` int NOT NULL,
  `FechaCalibracion` datetime NOT NULL,
  PRIMARY KEY (`IDCalibracion`),
  KEY `FKIdInstrumento_idx` (`IDInstrumento`),
  CONSTRAINT `FKIdInstrumento` FOREIGN KEY (`IDInstrumento`) REFERENCES `instrumento` (`IDInstrumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `medicion` (
  `IDMedicion` int unsigned NOT NULL,
  `IDCalibracion` int unsigned NOT NULL,
  `IDMedidaCalibracion` int NOT NULL,
  `Referencia` int NOT NULL,
  `Lectura` varchar(45) NOT NULL,
  `medicioncol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`IDMedicion`),
  KEY `FKIDCalibracion_idx` (`IDCalibracion`),
  CONSTRAINT `FKIDCalibracion` FOREIGN KEY (`IDCalibracion`) REFERENCES `calibracion` (`IDCalibracion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



