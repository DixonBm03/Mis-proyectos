/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import Coneccion.datacontract.Instrumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author busto
 */
public class ConsultaInstrumento extends BDconeccion{
    public void insertarInstrumento(Instrumento instrumento) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Consulta SQL para insertar un nuevo instrumento
            String sqlInsert = "INSERT INTO silab.instrumento (IDInstrumento, CodigoTipoInstrumento, Description, minimo, maximo, tolerancia) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);

            // Establecer los valores de los parámetros
            preparedStatement.setInt(1, (int) instrumento.getSerie());
            preparedStatement.setString(2, instrumento.getCodigoTipoInstrumento());
            preparedStatement.setString(3, instrumento.getDescripcion());
            preparedStatement.setInt(4, instrumento.getMinimo());
            preparedStatement.setInt(5, instrumento.getMaximo());
            preparedStatement.setInt(6, instrumento.getTolerancia());
        
            // Ejecutar la consulta de inserción
            int filasAfectadas = preparedStatement.executeUpdate();
        
            if (filasAfectadas > 0) {
                // La inserción fue exitosa, puedes obtener el ID generado
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    long idInstrumento = generatedKeys.getLong(1);
                    System.out.println("Inserción exitosa. ID del instrumento: " + idInstrumento);
                }
            } else {
                System.out.println("La inserción no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar datos en la tabla 'instrumento': " + e.getMessage());
        } finally {
             try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public void actualizarInstrumento(Instrumento instrumento) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
             // Consulta SQL para actualizar un registro de la tabla "instrumento" por su ID
            String sqlUpdate = "UPDATE silab.instrumento SET CodigoTipoInstrumento = ?, Description = ?, minimo = ?, maximo = ?, tolerancia = ? WHERE IDInstrumento = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sqlUpdate);

            // Establecer los valores de los parámetros
            preparedStatement.setString(1, instrumento.getCodigoTipoInstrumento());
            preparedStatement.setString(2, instrumento.getDescripcion());
            preparedStatement.setInt(3, instrumento.getMinimo());
            preparedStatement.setInt(4, instrumento.getMaximo());
            preparedStatement.setInt(5, instrumento.getTolerancia());
            preparedStatement.setLong(6, instrumento.getSerie());

            // Ejecutar la consulta de actualización
            int filasAfectadas = preparedStatement.executeUpdate();
        
            if (filasAfectadas > 0) {
               System.out.println("Actualización exitosa para el instrumento con ID: " + instrumento.getSerie());
           } else {
               System.out.println("La actualización no se realizó correctamente.");
           }
        } catch (SQLException e) {
            System.out.println("Error al actualizar datos en la tabla 'instrumento': " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public boolean buscarInstrumentoPorValor(Object valorABuscar) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            String sqlSelect = "SELECT * FROM silab.instrumento WHERE IDInstrumento = ? OR Description LIKE ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sqlSelect);

            // Establecer el valor del parámetro
            if (valorABuscar instanceof Integer) {
                // Si el valor es un entero, buscar por IDInstrumento
                preparedStatement.setInt(1, (int) valorABuscar);
                preparedStatement.setString(2, ""); // Ignorar Descripcion
            } else if (valorABuscar instanceof String) {
                // Si el valor es una cadena, buscar por Descripcion
                preparedStatement.setInt(1, 0); // Ignorar IDInstrumento
                preparedStatement.setString(2, "%" + (String) valorABuscar + "%");
            } else {
                System.out.println("Tipo de valor no válido.");
                 return false;
            }

            // Ejecutar la consulta de búsqueda
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Se encontraron resultados
                System.out.println("Se encontró un registro en la tabla 'instrumento'.");
                return true;
            } else {
                System.out.println("No se encontraron registros en la tabla 'instrumento'.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar datos en la tabla 'instrumento': " + e.getMessage());
            return false;
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public void eliminarInstrumentoPorNumeroDeFila(int numeroFila) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

         try {
            // Definir una sentencia SQL para obtener el ID del instrumento en la fila especificada
            String sqlSelect = "SELECT IDInstrumento FROM silab.instrumento LIMIT 1 OFFSET ?";
            PreparedStatement preparedStatementSelect = conn.prepareStatement(sqlSelect);
            preparedStatementSelect.setInt(1, numeroFila - 1); // Restar 1 para obtener el índice correcto (0-based index)

            ResultSet resultSet = preparedStatementSelect.executeQuery();

            int idInstrumentoAEliminar = 0;
            if (resultSet.next()) {
               idInstrumentoAEliminar = resultSet.getInt("IDInstrumento");
            } else {
                System.out.println("Número de fila no válido.");
                return; // Salir si no se encontró la fila
            }

            // Definir una sentencia SQL para eliminar el instrumento por su ID
            String sqlDelete = "DELETE FROM silab.instrumento WHERE IDInstrumento = ?";
            PreparedStatement preparedStatementDelete = conn.prepareStatement(sqlDelete);
            preparedStatementDelete.setInt(1, idInstrumentoAEliminar);
        
            // Ejecutar la sentencia de eliminación
            int filasAfectadas = preparedStatementDelete.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
            System.out.println("Eliminación exitosa en la base de datos.");
            } else {
                System.out.println("No se encontró el instrumento en la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el instrumento en la base de datos: " + e.getMessage());
        } finally {
            try {
             // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
