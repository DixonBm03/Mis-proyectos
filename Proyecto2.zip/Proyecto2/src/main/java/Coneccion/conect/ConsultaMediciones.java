/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import Coneccion.datacontract.Mediciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author busto
 */
public class ConsultaMediciones extends BDconeccion{
     public void insertarMedicion(Mediciones medicion) {
         Connection conexion = estableceConeccion();
        if (conexion == null) {
            System.out.println("Error al establecer la conexión a la base de datos.");
            return;
        }

        String sql = "INSERT INTO medicion (IDMedicion, IDCalibracion, IDMedidaCalibracion, Referencia, Lectura, medicioncol) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement insertStatement = conexion.prepareStatement(sql)) {
            insertStatement.setInt(1, medicion.getIDMedicion());
            insertStatement.setInt(2, medicion.getIDCalibracion());
            insertStatement.setInt(3, medicion.getIDMedidaCalibracion());
            insertStatement.setInt(4, medicion.getReferencia());
            insertStatement.setString(5, medicion.getLectura());
            insertStatement.setString(6, medicion.getMedicioncol());

            int filasAfectadas = insertStatement.executeUpdate();

            if (filasAfectadas == 1) {
                System.out.println("Inserción exitosa.");
            } else {
                System.out.println("La inserción no se realizó completamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar datos: " + e.getMessage());
        }
    }
    public boolean eliminarMedicionPorNumeroDeFila(int numeroFila) {
    // Llama al método para establecer la conexión a la base de datos
    Connection conn = estableceConeccion();

    try {
        // Consulta SQL para seleccionar el IDMedicion de la fila en la posición indicada
        String sqlSelect = "SELECT IDMedicion FROM medicion LIMIT 1 OFFSET ?";
        PreparedStatement preparedStatementSelect = conn.prepareStatement(sqlSelect);
        preparedStatementSelect.setInt(1, numeroFila - 1); // Restamos 1 para obtener el índice correcto (0-based index)

        ResultSet resultSet = preparedStatementSelect.executeQuery();

        int idMedicionAEliminar = 0;

        if (resultSet.next()) {
            idMedicionAEliminar = resultSet.getInt("IDMedicion");
        } else {
            System.out.println("Número de fila no válido.");
            return false; // Salir si no se encontró la fila
        }

        // Consulta SQL para eliminar la fila usando el IDMedicion obtenido
        String sqlDelete = "DELETE FROM medicion WHERE IDMedicion = ?";
        PreparedStatement preparedStatementDelete = conn.prepareStatement(sqlDelete);
        preparedStatementDelete.setInt(1, idMedicionAEliminar);

        int filasAfectadas = preparedStatementDelete.executeUpdate();

        // Realizar validaciones
        if (filasAfectadas > 0) {
            System.out.println("Eliminación exitosa.");
            return true;
        } else {
            System.out.println("La eliminación no se realizó correctamente.");
            return false;
        }
    } catch (SQLException e) {
        System.out.println("Error al eliminar medición: " + e.getMessage());
        return false;
    } finally {
        try {
            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
}



