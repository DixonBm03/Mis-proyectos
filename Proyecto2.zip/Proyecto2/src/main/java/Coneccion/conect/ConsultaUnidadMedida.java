/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import Coneccion.datacontract.UnidadMedida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author busto
 */
public class ConsultaUnidadMedida extends BDconeccion{
    // Método para insertar una Unidad de Medida
    public void insertarUnidadMedida(UnidadMedida unidadMedida) {
    // Llama al método para establecer la conexión a la base de datos
    Connection conn = estableceConeccion();

    // Consulta SQL para la inserción, sin incluir IDUnidadMedida
    String sql = "INSERT INTO silab.unidadmedida (Nombre, Sigla) VALUES (?, ?)";

    try {
        // Preparar la sentencia SQL
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, unidadMedida.getNombre());
        preparedStatement.setString(2, unidadMedida.getSigla());

        // Ejecutar la consulta y obtener el número de filas afectadas
        int filasAfectadas = preparedStatement.executeUpdate();

        // Realizar validaciones
        if (filasAfectadas > 0) {
            System.out.println("Inserción exitosa.");
        } else {
            System.out.println("La inserción no se realizó correctamente.");
        }
    } catch (SQLException e) {
        System.out.println("Error al insertar datos: " + e.getMessage());
    } finally {
        try {
            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
     // Método para modificar una Unidad de Medida
    public void modificarUnidadMedida(UnidadMedida unidadMedida) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Consulta SQL para la modificación
            String sql = "UPDATE silab.unidadmedida SET Nombre = ?, Sigla = ? WHERE IDUnidadMedida = ?";

            // Preparar la sentencia SQL
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, unidadMedida.getNombre());
            preparedStatement.setString(2, unidadMedida.getSigla());
            preparedStatement.setInt(3, unidadMedida.getID());

            // Ejecutar la consulta
            int filasAfectadas = preparedStatement.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
                System.out.println("Modificación exitosa.");
            } else {
                System.out.println("La modificación no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al modificar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public List<UnidadMedida> buscarUnidadMedidaPorNombreOSigla(String consulta) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();
        
        List<UnidadMedida> resultado = new ArrayList<>();

        try {
            // Consulta SQL para buscar por nombre o sigla
            String sql = "SELECT * FROM silab.unidadmedida WHERE Nombre LIKE ? OR Sigla LIKE ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            
            // Utilizamos el carácter '%' para buscar cualquier coincidencia
            preparedStatement.setString(1, "%" + consulta + "%");
            preparedStatement.setString(2, "%" + consulta + "%");
            
            // Ejecutar la consulta
            ResultSet resultSet = preparedStatement.executeQuery();

            // Recuperar los resultados
            while (resultSet.next()) {
                UnidadMedida unidadMedida = new UnidadMedida();
                unidadMedida.setID(resultSet.getInt("IDUnidadMedida"));
                unidadMedida.setNombre(resultSet.getString("Nombre"));
                unidadMedida.setSigla(resultSet.getString("Sigla"));
                resultado.add(unidadMedida);
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
        
        return resultado;
    }
        // Método para eliminar una fila específica por número de fila
     public void eliminarUnidadMedidaPorNumeroDeFila(int numeroFila) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Obtener el ID de la fila que se desea eliminar
            String sqlSelect = "SELECT IDUnidadMedida FROM silab.unidadmedida LIMIT ? OFFSET ?";
            PreparedStatement preparedStatementSelect = conn.prepareStatement(sqlSelect);
            preparedStatementSelect.setInt(1, 1); // Selecciona solo 1 fila
            preparedStatementSelect.setInt(2, numeroFila - 1); // Restamos 1 para obtener el índice correcto (0-based index)

            ResultSet resultSet = preparedStatementSelect.executeQuery();

            int idUnidadMedidaAEliminar = 0;
            if (resultSet.next()) {
                idUnidadMedidaAEliminar = resultSet.getInt("IDUnidadMedida");
            } else {
                System.out.println("Número de fila no válido.");
                return; // Salir si no se encontró la fila
            }

            // Eliminar la fila por ID
            String sqlDelete = "DELETE FROM silab.unidadmedida WHERE IDUnidadMedida = ?";
            PreparedStatement preparedStatementDelete = conn.prepareStatement(sqlDelete);
            preparedStatementDelete.setInt(1, idUnidadMedidaAEliminar);

            int filasAfectadas = preparedStatementDelete.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
                System.out.println("Eliminación exitosa.");
            } else {
                System.out.println("La eliminación no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
