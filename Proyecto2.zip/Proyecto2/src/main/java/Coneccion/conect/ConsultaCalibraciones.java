/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import Coneccion.datacontract.Calibraciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author busto
 */
public class ConsultaCalibraciones extends BDconeccion{
    public void insertarCalibracion(Calibraciones calibracion) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Definir la sentencia SQL para insertar una nueva calibración
            String sqlInsert = "INSERT INTO silab.calibracion (IDInstrumento, IDCalibracionInstrumento, FechaCalibracion) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sqlInsert);
            preparedStatement.setInt(1, calibracion.getIDInstrumento());
            preparedStatement.setInt(2, calibracion.getMedicion());
            preparedStatement.setTimestamp(3, new java.sql.Timestamp(calibracion.getFecha().getTime()));

            // Ejecutar la sentencia de inserción
            int filasAfectadas = preparedStatement.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
                System.out.println("Inserción de calibración exitosa en la base de datos.");
            } else {
                System.out.println("La inserción de calibración no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar datos de calibración en la base de datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public void actualizarCalibracionInstrumento(Calibraciones calibracion) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Define la sentencia SQL de actualización
             String sql = "UPDATE calibracion SET IDCalibracionInstrumento = ?";

            // Crea un PreparedStatement
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            // Establece el valor de IDCalibracionInstrumento en la sentencia SQL
             preparedStatement.setInt(1, calibracion.getMedicion());

            // Ejecuta la sentencia de actualización
            int filasAfectadas = preparedStatement.executeUpdate();
        
            // Realiza validaciones
            if (filasAfectadas > 0) {
                System.out.println("Actualización exitosa.");
            } else {
                System.out.println("La actualización no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar datos: " + e.getMessage());
        } finally {
            try {
                // Cierra la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public boolean buscarCalibracionPorIDCalibracionInstrumento(int idCalibracionInstrumento) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

         try {
            // Define la sentencia SQL para buscar una calibración por IDCalibracionInstrumento
            String sql = "SELECT IDCalibracion FROM calibracion WHERE IDCalibracionInstrumento = ?";

            // Crea un PreparedStatement
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            // Establece el valor de IDCalibracionInstrumento en la sentencia SQL
            preparedStatement.setInt(1, idCalibracionInstrumento);

            // Ejecuta la consulta
            ResultSet resultSet = preparedStatement.executeQuery();

            // Verifica si se encontró una calibración
            if (resultSet.next()) {
               return true; // Se encontró una coincidencia
            }   
        } catch (SQLException e) {
            System.out.println("Error al buscar calibración por IDCalibracionInstrumento: " + e.getMessage());
        } finally {
            try {
            // Cierra la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }

        return false; // No se encontró ninguna coincidencia
    }
    public boolean eliminarCalibracionPorNumeroDeFila(int numeroFila) {
    // Llama al método para establecer la conexión a la base de datos
    Connection conn = estableceConeccion();

    try {
        // Obtener el IDCalibracion y IDCalibracionInstrumento de la fila que se desea eliminar
        String sqlSelect = "SELECT IDCalibracion, IDCalibracionInstrumento FROM calibracion LIMIT ? OFFSET ?";
        PreparedStatement preparedStatementSelect = conn.prepareStatement(sqlSelect);
        preparedStatementSelect.setInt(1, 1); // Selecciona solo 1 fila
        preparedStatementSelect.setInt(2, numeroFila - 1); // Restamos 1 para obtener el índice correcto (0-based index)

        ResultSet resultSet = preparedStatementSelect.executeQuery();

        int idCalibracionAEliminar = 0;
        int idCalibracionInstrumento = 0;

        if (resultSet.next()) {
            idCalibracionAEliminar = resultSet.getInt("IDCalibracion");
            idCalibracionInstrumento = resultSet.getInt("IDCalibracionInstrumento");
        } else {
            System.out.println("Número de fila no válido.");
            return false; // Salir si no se encontró la fila
        }

        if (idCalibracionInstrumento == 0) {
            // Si IDCalibracionInstrumento es igual a 0, eliminar directamente
            String sqlDelete = "DELETE FROM calibracion WHERE IDCalibracion = ?";
            PreparedStatement preparedStatementDelete = conn.prepareStatement(sqlDelete);
            preparedStatementDelete.setInt(1, idCalibracionAEliminar);

            int filasAfectadas = preparedStatementDelete.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
                System.out.println("Eliminación exitosa.");
                return true;
            } else {
                System.out.println("La eliminación no se realizó correctamente.");
                return false;
            }
        } else {
            System.out.println("No se puede eliminar porque tiene mediciones agregadas.");
            return false;
        }
    } catch (SQLException e) {
        System.out.println("Error al eliminar calibración: " + e.getMessage());
        return false;
    } finally {
        try {
            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}

}
