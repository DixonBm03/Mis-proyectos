/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author busto
 */
public class BDconeccion {
    Connection con = null;
    String base = "silab";
    String url = "jdbc:mysql://localhost:3306/" + base;
    String user = "root";
    String password = "dixon1903";

    public Connection estableceConeccion() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);
            System.out.println("Conexion a la base de datos Exitosa!!!");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e);
            System.out.println("Conexion a la base de datos Fallida!!!");
        }
        return con;
    }
}
