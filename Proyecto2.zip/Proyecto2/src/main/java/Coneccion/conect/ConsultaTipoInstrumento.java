/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion.conect;

import Coneccion.datacontract.TipoInstrumento;
import Coneccion.datacontract.UnidadMedida;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author busto
 */
public class ConsultaTipoInstrumento extends BDconeccion{
    public void insertarTipoInstrumento(TipoInstrumento tipoInstrumento) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
           
            // Comprueba si la Unidad de Medida con el ID proporcionado existe en la tabla "unidadmedida"
            if (existeUnidadMedida(conn, tipoInstrumento.getUnidad().getID())) {
                // Consulta SQL para la inserción
                String sql = "INSERT INTO silab.tipoinstrumento (CodigoTipoInstrumento, NombreTipoInstrumento, IDUnidadMedida) VALUES (?, ?, ?)";

                // Preparar la sentencia SQL
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, tipoInstrumento.getCodigo());
                preparedStatement.setString(2, tipoInstrumento.getNombre());
                preparedStatement.setInt(3, tipoInstrumento.getUnidad().getID());

                // Ejecutar la consulta
                int filasAfectadas = preparedStatement.executeUpdate();

                // Realizar validaciones
                if (filasAfectadas > 0) {
                    System.out.println("Inserción exitosa.");
                } else {
                    System.out.println("La inserción no se realizó correctamente.");
                }
            } else {
                System.out.println("La Unidad de Medida con ID " + tipoInstrumento.getUnidad().getID() + " no existe.");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }

    // Método para comprobar si una Unidad de Medida con el ID dado existe en la tabla "unidadmedida"
    private boolean existeUnidadMedida(Connection conn, int idUnidadMedida) throws SQLException {
        String sql = "SELECT IDUnidadMedida FROM silab.unidadmedida WHERE IDUnidadMedida = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setInt(1, idUnidadMedida);
        return preparedStatement.executeQuery().next();
    }
    public void modificarTipoInstrumento(TipoInstrumento tipoInstrument) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Comprueba si la Unidad de Medida con el ID proporcionado existe en la tabla "unidadmedida"
            if (existeUnidadMedida(conn, tipoInstrument.getUnidad().getID())) {
                // Consulta SQL para la modificación
                String sql = "UPDATE silab.tipoinstrumento SET CodigoTipoInstrumento = ?, NombreTipoInstrumento = ? WHERE IDUnidadMedida = ?";

                // Preparar la sentencia SQL
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, tipoInstrument.getCodigo());
                preparedStatement.setString(2, tipoInstrument.getNombre());
                preparedStatement.setInt(3, tipoInstrument.getUnidad().getID());

                // Ejecutar la consulta
                int filasAfectadas = preparedStatement.executeUpdate();

                // Realizar validaciones
                if (filasAfectadas > 0) {
                    System.out.println("Modificación exitosa.");
                } else {
                    System.out.println("La modificación no se realizó correctamente.");
                }
            } else {
                System.out.println("La Unidad de Medida con ID " + tipoInstrument.getUnidad().getID() + " no existe.");
            }
        } catch (SQLException e) {
            System.out.println("Error al modificar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
    public List<TipoInstrumento> buscarTipoInstrumentoPorNombreOCodigo(String consulta) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();
        
        List<TipoInstrumento> resultado = new ArrayList<>();

        try {
            // Consulta SQL para buscar por nombre o código
            String sql = "SELECT * FROM silab.tipoinstrumento WHERE NombreTipoInstrumento LIKE ? OR CodigoTipoInstrumento LIKE ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            
            // Utilizamos el carácter '%' para buscar cualquier coincidencia
            preparedStatement.setString(1, "%" + consulta + "%");
            preparedStatement.setString(2, "%" + consulta + "%");
            
            // Ejecutar la consulta
            ResultSet resultSet = preparedStatement.executeQuery();

            // Recuperar los resultados
            while (resultSet.next()) {
                TipoInstrumento tipoInstrumento = new TipoInstrumento();
                tipoInstrumento.setCodigo(resultSet.getString("CodigoTipoInstrumento"));
                tipoInstrumento.setNombre(resultSet.getString("NombreTipoInstrumento"));
                // Agrega cualquier otra propiedad que desees recuperar

                resultado.add(tipoInstrumento);
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
        
        return resultado;
    }
    public void eliminarTipoInstrumentoPorNumeroDeFila(int numeroFila) {
        // Llama al método para establecer la conexión a la base de datos
        Connection conn = estableceConeccion();

        try {
            // Obtener el ID del Tipo de Instrumento que se desea eliminar
            String sqlSelect = "SELECT IDUnidadMedida FROM silab.tipoinstrumento LIMIT ? OFFSET ?";
            PreparedStatement preparedStatementSelect = conn.prepareStatement(sqlSelect);
            preparedStatementSelect.setInt(1, 1); // Selecciona solo 1 fila
            preparedStatementSelect.setInt(2, numeroFila - 1); // Restamos 1 para obtener el índice correcto (0-based index)

            ResultSet resultSet = preparedStatementSelect.executeQuery();

           int idTipoInstrumentoAEliminar = 0;
            if (resultSet.next()) {
                idTipoInstrumentoAEliminar = resultSet.getInt("IDUnidadMedida");
            } else {
                System.out.println("Número de fila no válido.");
                return; // Salir si no se encontró la fila
            }

            // Eliminar el Tipo de Instrumento por ID
            String sqlDelete = "DELETE FROM silab.tipoinstrumento WHERE IDUnidadMedida = ?";
            PreparedStatement preparedStatementDelete = conn.prepareStatement(sqlDelete);
            preparedStatementDelete.setInt(1, idTipoInstrumentoAEliminar);

            int filasAfectadas = preparedStatementDelete.executeUpdate();

            // Realizar validaciones
            if (filasAfectadas > 0) {
                System.out.println("Eliminación exitosa.");
            } else {
                System.out.println("La eliminación no se realizó correctamente.");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar datos: " + e.getMessage());
        } finally {
            try {
                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}

